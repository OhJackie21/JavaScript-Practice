import React from 'react'

const Home = (props) => {
  return (
    <div>Welcome</div>
  )
}

export default Home